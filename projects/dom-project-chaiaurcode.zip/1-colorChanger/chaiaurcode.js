const body = document.querySelector("body");
// console.log(body);
const buttons = document.querySelectorAll(".button");


buttons.forEach(function(button) {
  button.addEventListener("click", function(event) {
    console.log(event);
  })
})
